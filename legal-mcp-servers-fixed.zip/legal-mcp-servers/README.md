# Legal Research MCP Server Suite

A comprehensive set of MCP (Model Context Protocol) servers for retrieving **verified legal text** from official government sources. Built for self-represented litigants and legal researchers who need accurate statutory and regulatory text for AI-assisted legal analysis.

## The Problem This Solves

AI models hallucinate legal citations. This suite solves that by:

1. Fetching **official text** from government sources
2. Providing **verifiable URLs** for every citation
3. Enabling Claude to analyze **actual law**, not training data approximations

## Included Servers

| Server | Source | What It Covers |
|--------|--------|----------------|
| `california-law-mcp-server` | leginfo.legislature.ca.gov | California statutory codes (FAM, PEN, WIC, CCP, etc.) |
| `california-rules-of-court-mcp-server` | courts.ca.gov | California Rules of Court (CRC 5.220, 5.225, etc.) |
| `california-regulations-mcp-server` | govt.westlaw.com/calregs | California Code of Regulations (POST, CDSS, Medical Board) |
| `us-code-mcp-server` | law.cornell.edu | United States Code (42 USC § 1983, etc.) |

## Quick Start

### Prerequisites
- Node.js 18 or higher
- Claude Desktop app

### Installation

```bash
# Extract the package
unzip legal-mcp-servers.zip
cd legal-mcp-servers

# Install all servers
for dir in */; do
  echo "Installing $dir..."
  cd "$dir"
  npm install
  cd ..
done
```

### Configure Claude Desktop

Edit your Claude Desktop config file:
- **Mac/Linux:** `~/.config/claude/claude_desktop_config.json`
- **Windows:** `%APPDATA%\Claude\claude_desktop_config.json`

```json
{
  "mcpServers": {
    "california-law": {
      "command": "node",
      "args": ["/full/path/to/california-law-mcp-server/dist/index.js"]
    },
    "california-rules": {
      "command": "node",
      "args": ["/full/path/to/california-rules-of-court-mcp-server/dist/index.js"]
    },
    "california-regulations": {
      "command": "node",
      "args": ["/full/path/to/california-regulations-mcp-server/dist/index.js"]
    },
    "us-code": {
      "command": "node",
      "args": ["/full/path/to/us-code-mcp-server/dist/index.js"]
    }
  }
}
```

Restart Claude Desktop after saving.

## Usage Examples

Once configured, you can ask Claude:

### California Statutory Law
- "Get Family Code section 3044 and analyze if the DV presumption applies"
- "What does Penal Code 273.5 say?"
- "Get WIC 300 and explain the grounds for dependency jurisdiction"

### California Rules of Court
- "Get CRC Rule 5.220 and tell me the requirements for custody evaluators"
- "What does Rule 5.225 require for recommending counselors?"
- "Show me the domestic violence protocol rules for mediators"

### California Regulations
- "What are the POST training standards for law enforcement?"
- "What does CDSS require for CPS investigations?"
- "Show me the Medical Board regulations on unprofessional conduct"

### Federal Civil Rights
- "Get 42 USC 1983 and explain the elements"
- "What does 18 USC 242 say about deprivation of rights?"
- "Show me the federal question jurisdiction statute"

## Available Tools

### California Law Server
| Tool | Description |
|------|-------------|
| `california_get_section` | Retrieve full text of any CA code section |
| `california_search_code` | Search within a code by keyword |
| `california_list_codes` | List all 30 California codes |

### California Rules of Court Server
| Tool | Description |
|------|-------------|
| `crc_get_rule` | Retrieve full text of a CRC rule |
| `crc_search_rules` | Search rules by keyword |
| `crc_list_titles` | List all CRC titles |
| `crc_list_key_rules` | List key family law rules |

### California Regulations Server
| Tool | Description |
|------|-------------|
| `ccr_get_regulation` | Retrieve CCR section |
| `ccr_list_titles` | List all CCR titles |
| `ccr_list_key_regulations` | List key POST/CPS/Medical regs |

### US Code Server
| Tool | Description |
|------|-------------|
| `usc_get_section` | Retrieve USC section from Cornell LII |
| `usc_list_titles` | List all 54 USC titles |
| `usc_list_civil_rights_sections` | List key § 1983 sections |

## Key Sections Reference

### Family Law / Custody
| Source | Section | Topic |
|--------|---------|-------|
| FAM | § 3044 | DV presumption against custody |
| FAM | § 3020 | Best interest of child |
| FAM | § 3040 | Custody order priorities |
| CRC | 5.220 | Custody evaluation standards |
| CRC | 5.225 | Recommending counselor requirements |
| CRC | 5.215 | DV protocol for mediators |

### Civil Rights
| Source | Section | Topic |
|--------|---------|-------|
| 42 USC | § 1983 | Civil action for deprivation of rights |
| 42 USC | § 1985 | Conspiracy to interfere with rights |
| 18 USC | § 242 | Deprivation of rights (criminal) |
| 28 USC | § 1331 | Federal question jurisdiction |

### Law Enforcement Standards
| Source | Section | Topic |
|--------|---------|-------|
| 11 CCR | § 1001 | POST authority |
| 11 CCR | § 1002 | Selection standards |
| 11 CCR | § 1005 | Training standards |

### CPS / Child Welfare
| Source | Section | Topic |
|--------|---------|-------|
| WIC | § 300 | Dependency jurisdiction |
| WIC | § 361.5 | Reunification services |
| 22 CCR | § 31061 | Investigation requirements |

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     Claude Desktop                           │
│                          ↓                                   │
│  ┌─────────────────────────────────────────────────────────┐│
│  │                   MCP Protocol                          ││
│  └─────────────────────────────────────────────────────────┘│
│       ↓              ↓              ↓              ↓        │
│  ┌─────────┐   ┌─────────┐   ┌─────────┐   ┌─────────┐     │
│  │ CA Law  │   │ CA CRC  │   │ CA CCR  │   │ US Code │     │
│  │ Server  │   │ Server  │   │ Server  │   │ Server  │     │
│  └────┬────┘   └────┬────┘   └────┬────┘   └────┬────┘     │
│       ↓              ↓              ↓              ↓        │
│  ┌─────────┐   ┌─────────┐   ┌─────────┐   ┌─────────┐     │
│  │leginfo.│   │courts.  │   │westlaw  │   │cornell  │     │
│  │ca.gov  │   │ca.gov   │   │calregs  │   │lii      │     │
│  └─────────┘   └─────────┘   └─────────┘   └─────────┘     │
└─────────────────────────────────────────────────────────────┘
```

## Limitations

- **Internet required** — Servers fetch from live government sites
- **California focus** — Other states would need separate servers
- **No case law** — Statutes and regulations only (no court opinions)
- **Site changes** — Government websites may change structure

## Extending

Each server follows the same pattern. To add support for another source:

1. Copy a server directory
2. Update the URL fetching logic
3. Update the parsing logic for the new site's HTML structure
4. Update tool names and descriptions

## License

MIT — Use freely for legal research and self-representation.

## Disclaimer

These tools retrieve official legal text but do not constitute legal advice. Always verify current law and consider consulting with an attorney for legal matters.
