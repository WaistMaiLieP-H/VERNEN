import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import express, { Request, Response } from "express";
import { z } from "zod";
import { parse } from "node-html-parser";

// ============================================================================
// CONSTANTS
// ============================================================================

const US_CODE_TITLES: Record<string, string> = {
  "1": "General Provisions",
  "2": "The Congress",
  "3": "The President",
  "4": "Flag and Seal, Seat of Government, and the States",
  "5": "Government Organization and Employees",
  "6": "Domestic Security",
  "7": "Agriculture",
  "8": "Aliens and Nationality",
  "9": "Arbitration",
  "10": "Armed Forces",
  "11": "Bankruptcy",
  "12": "Banks and Banking",
  "13": "Census",
  "14": "Coast Guard",
  "15": "Commerce and Trade",
  "16": "Conservation",
  "17": "Copyrights",
  "18": "Crimes and Criminal Procedure",
  "19": "Customs Duties",
  "20": "Education",
  "21": "Food and Drugs",
  "22": "Foreign Relations and Intercourse",
  "23": "Highways",
  "24": "Hospitals and Asylums",
  "25": "Indians",
  "26": "Internal Revenue Code",
  "27": "Intoxicating Liquors",
  "28": "Judiciary and Judicial Procedure",
  "29": "Labor",
  "30": "Mineral Lands and Mining",
  "31": "Money and Finance",
  "32": "National Guard",
  "33": "Navigation and Navigable Waters",
  "34": "Crime Control and Law Enforcement",
  "35": "Patents",
  "36": "Patriotic and National Observances",
  "37": "Pay and Allowances of the Uniformed Services",
  "38": "Veterans' Benefits",
  "39": "Postal Service",
  "40": "Public Buildings, Property, and Works",
  "41": "Public Contracts",
  "42": "The Public Health and Welfare",
  "43": "Public Lands",
  "44": "Public Printing and Documents",
  "45": "Railroads",
  "46": "Shipping",
  "47": "Telecommunications",
  "48": "Territories and Insular Possessions",
  "49": "Transportation",
  "50": "War and National Defense",
  "51": "National and Commercial Space Programs",
  "52": "Voting and Elections",
  "53": "Reserved",
  "54": "National Park Service and Related Programs",
};

// Key sections for civil rights litigation
const KEY_CIVIL_RIGHTS_SECTIONS: Record<string, string> = {
  "42-1983": "Civil action for deprivation of rights (Section 1983)",
  "42-1985": "Conspiracy to interfere with civil rights",
  "42-1986": "Action for neglect to prevent conspiracy",
  "42-1988": "Proceedings in vindication of civil rights",
  "18-241": "Conspiracy against rights",
  "18-242": "Deprivation of rights under color of law",
  "18-1001": "False statements",
  "18-1621": "Perjury",
  "18-1622": "Subornation of perjury",
  "28-1331": "Federal question jurisdiction",
  "28-1343": "Civil rights and elective franchise",
  "28-1915": "Proceedings in forma pauperis",
  "42-14141": "Pattern or practice of police misconduct (DOJ)",
};

const CORNELL_LII_BASE = "https://www.law.cornell.edu/uscode/text";
const CHARACTER_LIMIT = 50000;

// ============================================================================
// SERVER INITIALIZATION
// ============================================================================

const server = new McpServer({
  name: "us-code-mcp-server",
  version: "1.0.0",
});

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

async function fetchWithTimeout(
  url: string,
  timeoutMs: number = 30000
): Promise<string> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: {
        "User-Agent": "US-Code-MCP-Server/1.0 (Legal Research Tool)",
        Accept: "text/html,application/xhtml+xml",
      },
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    return await response.text();
  } finally {
    clearTimeout(timeoutId);
  }
}

function cleanText(text: string): string {
  return text
    .replace(/\s+/g, " ")
    .replace(/\n\s*\n/g, "\n\n")
    .trim();
}

function truncateIfNeeded(text: string, limit: number = CHARACTER_LIMIT): string {
  if (text.length <= limit) return text;
  return (
    text.substring(0, limit) +
    `\n\n[TRUNCATED - Response exceeded ${limit} characters.]`
  );
}

// ============================================================================
// US CODE FETCHER
// ============================================================================

async function fetchSection(
  title: string,
  section: string
): Promise<{ text: string; url: string; heading: string }> {
  // Cornell LII URL format: https://www.law.cornell.edu/uscode/text/42/1983
  const url = `${CORNELL_LII_BASE}/${title}/${section}`;

  const html = await fetchWithTimeout(url);
  const root = parse(html);

  // Extract section content
  const contentDiv =
    root.querySelector(".tab-pane.active") ||
    root.querySelector("#content") ||
    root.querySelector(".usc-content") ||
    root.querySelector("article") ||
    root.querySelector(".field-items");

  if (!contentDiv) {
    const bodyText = root.querySelector("body")?.text || "";
    if (bodyText.includes("404") || bodyText.includes("not found")) {
      throw new Error(
        `Section ${title} U.S.C. § ${section} not found. Verify the title and section numbers.`
      );
    }
    throw new Error(
      `Could not parse section content. The page structure may have changed.`
    );
  }

  // Get section heading
  const headingElement =
    root.querySelector("h1") ||
    root.querySelector(".headline") ||
    root.querySelector("h2");
  const heading = headingElement
    ? cleanText(headingElement.text)
    : `${title} U.S.C. § ${section}`;

  let text = contentDiv.text;
  text = cleanText(text);

  return { text, url, heading };
}

// ============================================================================
// TOOL SCHEMAS
// ============================================================================

const GetSectionInputSchema = z
  .object({
    title: z
      .string()
      .regex(/^\d+$/, "Title must be a number (e.g., '42')")
      .describe(
        `US Code title number. Key titles: 42 (Public Health/Civil Rights), 18 (Crimes), 28 (Judiciary)`
      ),
    section: z
      .string()
      .min(1)
      .max(20)
      .describe(
        `Section number (e.g., "1983" for civil rights, "242" for deprivation of rights)`
      ),
  })
  .strict();

const ListTitlesInputSchema = z.object({}).strict();

const ListCivilRightsSectionsInputSchema = z.object({}).strict();

// ============================================================================
// TOOL REGISTRATION
// ============================================================================

server.registerTool(
  "usc_get_section",
  {
    title: "Get US Code Section",
    description: `Retrieve the full text of a United States Code section from Cornell Law's Legal Information Institute.

This tool fetches VERIFIED statutory text from Cornell LII, a trusted legal source.

Args:
  - title (string): US Code title number (e.g., "42" for civil rights)
  - section (string): Section number (e.g., "1983")

Key Civil Rights Sections:
  - 42 USC § 1983: Civil action for deprivation of rights (THE key section)
  - 42 USC § 1985: Conspiracy to interfere with civil rights
  - 42 USC § 1986: Action for neglect to prevent conspiracy
  - 18 USC § 241: Conspiracy against rights (criminal)
  - 18 USC § 242: Deprivation of rights under color of law (criminal)

Returns:
  - Full statutory text from Cornell LII
  - Direct URL to the source
  - Section heading

Examples:
  - Section 1983: title="42", section="1983"
  - Deprivation of rights: title="18", section="242"
  - Federal question jurisdiction: title="28", section="1331"`,
    inputSchema: GetSectionInputSchema,
    annotations: {
      readOnlyHint: true,
      destructiveHint: false,
      idempotentHint: true,
      openWorldHint: true,
    },
  },
  async (params) => {
    try {
      const { title, section } = params;
      const result = await fetchSection(title, section);

      const titleDesc = US_CODE_TITLES[title] || "Unknown Title";

      const output = {
        title: title,
        title_name: titleDesc,
        section: section,
        heading: result.heading,
        text: truncateIfNeeded(result.text),
        source_url: result.url,
        citation: `${title} U.S.C. § ${section}`,
        retrieved_at: new Date().toISOString(),
        disclaimer:
          "This is statutory text from Cornell LII. Always verify currency and check for amendments.",
      };

      const markdown = `# ${title} U.S.C. § ${section}

**Title ${title}:** ${titleDesc}
**Citation:** ${output.citation}
**Source:** [Cornell Law - Legal Information Institute](${result.url})
**Retrieved:** ${output.retrieved_at}

---

## ${result.heading}

${result.text}

---

*Note: This is federal statutory text. Verify currency for any court filing.*`;

      return {
        content: [{ type: "text", text: markdown }],
        structuredContent: output,
      };
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : "Unknown error occurred";
      return {
        isError: true,
        content: [
          {
            type: "text",
            text: `Error retrieving ${params.title} U.S.C. § ${params.section}: ${errorMessage}\n\nTry:\n1. Verify the title and section numbers\n2. Use usc_list_civil_rights_sections to see key sections\n3. Use usc_list_titles to see all titles`,
          },
        ],
      };
    }
  }
);

server.registerTool(
  "usc_list_titles",
  {
    title: "List US Code Titles",
    description: `List all titles of the United States Code.

Returns:
  - Complete list of USC titles with descriptions`,
    inputSchema: ListTitlesInputSchema,
    annotations: {
      readOnlyHint: true,
      destructiveHint: false,
      idempotentHint: true,
      openWorldHint: false,
    },
  },
  async () => {
    const titles = Object.entries(US_CODE_TITLES).map(([num, desc]) => ({
      title_number: num,
      title_name: desc,
    }));

    const markdown = `# United States Code - Titles

| Title | Description |
|-------|-------------|
${titles.map((t) => `| ${t.title_number} | ${t.title_name} |`).join("\n")}

---

## Key Titles for Civil Rights Litigation

- **Title 42**: The Public Health and Welfare (includes § 1983)
- **Title 18**: Crimes and Criminal Procedure (federal civil rights crimes)
- **Title 28**: Judiciary and Judicial Procedure (jurisdiction, procedure)
- **Title 5**: Government Organization and Employees (APA, FOIA)

Use \`usc_get_section\` with title and section numbers.`;

    return {
      content: [{ type: "text", text: markdown }],
      structuredContent: { titles },
    };
  }
);

server.registerTool(
  "usc_list_civil_rights_sections",
  {
    title: "List Key Civil Rights Sections",
    description: `List key US Code sections for civil rights litigation against government actors.

Returns:
  - Important sections for Section 1983 claims
  - Federal criminal civil rights statutes
  - Jurisdictional provisions`,
    inputSchema: ListCivilRightsSectionsInputSchema,
    annotations: {
      readOnlyHint: true,
      destructiveHint: false,
      idempotentHint: true,
      openWorldHint: false,
    },
  },
  async () => {
    const sections = Object.entries(KEY_CIVIL_RIGHTS_SECTIONS).map(
      ([key, desc]) => {
        const [title, section] = key.split("-");
        return {
          citation: `${title} U.S.C. § ${section}`,
          title,
          section,
          description: desc,
          url: `${CORNELL_LII_BASE}/${title}/${section}`,
        };
      }
    );

    const markdown = `# Key Civil Rights Sections - United States Code

## Primary Civil Rights Statutes (Title 42)

| Citation | Description |
|----------|-------------|
| 42 U.S.C. § 1983 | **Civil action for deprivation of rights** - THE key statute for suing state actors |
| 42 U.S.C. § 1985 | Conspiracy to interfere with civil rights |
| 42 U.S.C. § 1986 | Action for neglect to prevent conspiracy |
| 42 U.S.C. § 1988 | Attorney fees in civil rights cases |

## Federal Criminal Civil Rights (Title 18)

| Citation | Description |
|----------|-------------|
| 18 U.S.C. § 241 | Conspiracy against rights (criminal) |
| 18 U.S.C. § 242 | Deprivation of rights under color of law (criminal) |

## Jurisdictional Statutes (Title 28)

| Citation | Description |
|----------|-------------|
| 28 U.S.C. § 1331 | Federal question jurisdiction |
| 28 U.S.C. § 1343 | Civil rights jurisdiction |
| 28 U.S.C. § 1915 | In forma pauperis proceedings |

---

## Section 1983 Elements

To prevail under 42 U.S.C. § 1983, a plaintiff must prove:
1. The defendant acted **under color of state law**
2. The defendant's conduct **deprived plaintiff of a federal right**

Use \`usc_get_section\` to retrieve full text of any section.`;

    return {
      content: [{ type: "text", text: markdown }],
      structuredContent: { sections },
    };
  }
);

// ============================================================================
// SERVER TRANSPORT
// ============================================================================

async function runStdio(): Promise<void> {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error("US Code MCP Server running on stdio");
}

async function runHTTP(): Promise<void> {
  const app = express();
  app.use(express.json());

  app.get("/health", (_req: Request, res: Response) => {
    res.json({ status: "ok", server: "us-code-mcp-server" });
  });

  app.post("/mcp", async (req: Request, res: Response) => {
    const transport = new StreamableHTTPServerTransport({
      sessionIdGenerator: undefined,
      enableJsonResponse: true,
    });
    res.on("close", () => transport.close());
    await server.connect(transport);
    await transport.handleRequest(req, res, req.body);
  });

  const port = parseInt(process.env.PORT || "3002");
  app.listen(port, () => {
    console.error(`US Code MCP Server running on http://localhost:${port}/mcp`);
  });
}

const transport = process.env.TRANSPORT || "stdio";
if (transport === "http") {
  runHTTP().catch((error) => {
    console.error("Server error:", error);
    process.exit(1);
  });
} else {
  runStdio().catch((error) => {
    console.error("Server error:", error);
    process.exit(1);
  });
}
