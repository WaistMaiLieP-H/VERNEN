import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import express, { Request, Response } from "express";
import { z } from "zod";
import { parse } from "node-html-parser";

// ============================================================================
// CONSTANTS
// ============================================================================

const CCR_TITLES: Record<string, string> = {
  "1": "General Provisions",
  "2": "Administration",
  "3": "Food and Agriculture",
  "4": "Business Regulations",
  "5": "Education",
  "8": "Industrial Relations",
  "9": "Rehabilitative and Developmental Services",
  "10": "Investment",
  "11": "Law Enforcement",
  "13": "Motor Vehicles",
  "14": "Natural Resources",
  "15": "Crime Prevention and Corrections",
  "16": "Professional and Vocational Regulations",
  "17": "Public Health",
  "18": "Public Revenues",
  "19": "Public Safety",
  "20": "Public Utilities and Energy",
  "21": "Public Works",
  "22": "Social Services",
  "23": "Waters",
  "24": "Housing and Community Development",
  "25": "Housing and Community Development",
  "27": "Environmental Protection",
  "28": "Managed Health Care",
};

// Key sections for your case
const KEY_REGULATORY_SECTIONS: Record<string, { title: string; section: string; description: string }> = {
  // POST Standards (Title 11)
  "post-training": { title: "11", section: "1005", description: "POST Minimum Standards for Training" },
  "post-selection": { title: "11", section: "1002", description: "POST Selection Standards" },
  "post-conduct": { title: "11", section: "1003", description: "POST Standards of Conduct" },
  
  // CDSS/CPS Standards (Title 22)
  "cps-investigation": { title: "22", section: "31061", description: "CPS Investigation Requirements" },
  "cps-reports": { title: "22", section: "31001", description: "Child Abuse Reporting Requirements" },
  "foster-care": { title: "22", section: "31101", description: "Foster Care Licensing Standards" },
  
  // Medical Board (Title 16)
  "medical-discipline": { title: "16", section: "1361", description: "Physician Discipline Grounds" },
  "medical-unprofessional": { title: "16", section: "2234", description: "Unprofessional Conduct Defined" },
  "psych-standards": { title: "16", section: "1397.61", description: "Psychology Board Standards" },
};

// Westlaw California Regulations URL (public access)
const CCR_BASE_URL = "https://govt.westlaw.com/calregs";
const CHARACTER_LIMIT = 50000;

// ============================================================================
// SERVER INITIALIZATION
// ============================================================================

const server = new McpServer({
  name: "california-regulations-mcp-server",
  version: "1.0.0",
});

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

async function fetchWithTimeout(
  url: string,
  timeoutMs: number = 30000
): Promise<string> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: {
        "User-Agent": "California-Regulations-MCP-Server/1.0 (Legal Research Tool)",
        Accept: "text/html,application/xhtml+xml",
      },
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    return await response.text();
  } finally {
    clearTimeout(timeoutId);
  }
}

function cleanText(text: string): string {
  return text
    .replace(/\s+/g, " ")
    .replace(/\n\s*\n/g, "\n\n")
    .trim();
}

function truncateIfNeeded(text: string, limit: number = CHARACTER_LIMIT): string {
  if (text.length <= limit) return text;
  return (
    text.substring(0, limit) +
    `\n\n[TRUNCATED - Response exceeded ${limit} characters.]`
  );
}

// ============================================================================
// CCR FETCHER
// ============================================================================

async function fetchRegulation(
  title: string,
  section: string
): Promise<{ text: string; url: string; heading: string }> {
  // Westlaw CalRegs URL format
  // Example: https://govt.westlaw.com/calregs/Document/I...
  // Alternative: Use search functionality
  
  // For now, construct a search URL
  const searchQuery = encodeURIComponent(`title ${title} section ${section}`);
  const url = `${CCR_BASE_URL}/Search/Index?transitionType=Default&contextData=(sc.Default)&t_T=${title}&t_S=${section}`;

  try {
    const html = await fetchWithTimeout(url);
    const root = parse(html);

    // Try to extract content from the regulation display
    const contentDiv =
      root.querySelector(".co_document") ||
      root.querySelector("#co_document") ||
      root.querySelector(".document-content") ||
      root.querySelector("article") ||
      root.querySelector(".content");

    if (!contentDiv) {
      // Provide alternative guidance
      throw new Error(
        `Direct fetch not available. Search manually at: ${CCR_BASE_URL}/Browse/Home/California/CaliforniaCodeofRegulations?transitionType=Default&contextData=(sc.Default)`
      );
    }

    const headingElement = root.querySelector("h1") || root.querySelector("h2");
    const heading = headingElement
      ? cleanText(headingElement.text)
      : `${title} CCR § ${section}`;

    let text = contentDiv.text;
    text = cleanText(text);

    return { text, url, heading };
  } catch (error) {
    // Fallback: provide the manual search URL
    const manualUrl = `${CCR_BASE_URL}/Browse/Home/California/CaliforniaCodeofRegulations?transitionType=Default&contextData=(sc.Default)`;
    throw new Error(
      `Could not auto-fetch regulation. Search manually:\n\n` +
      `1. Go to: ${manualUrl}\n` +
      `2. Navigate to Title ${title}\n` +
      `3. Search for Section ${section}\n\n` +
      `Title ${title}: ${CCR_TITLES[title] || "Unknown"}`
    );
  }
}

// ============================================================================
// TOOL SCHEMAS
// ============================================================================

const GetRegulationInputSchema = z
  .object({
    title: z
      .string()
      .regex(/^\d+$/, "Title must be a number")
      .describe(
        `CCR title number. Key titles: 11 (Law Enforcement/POST), 22 (Social Services/CPS), 16 (Professional Licensing/Medical Board)`
      ),
    section: z
      .string()
      .min(1)
      .max(20)
      .describe(`Section number within the title`),
  })
  .strict();

const ListTitlesInputSchema = z.object({}).strict();

const ListKeyRegulationsInputSchema = z
  .object({
    category: z
      .enum(["post", "cps", "medical", "all"])
      .default("all")
      .describe(`Category of regulations to list`),
  })
  .strict();

// ============================================================================
// TOOL REGISTRATION
// ============================================================================

server.registerTool(
  "ccr_get_regulation",
  {
    title: "Get California Code of Regulations Section",
    description: `Retrieve a California Code of Regulations (CCR) section.

Note: Due to Westlaw's structure, this may return a search URL rather than direct content.
The tool provides guidance for manual lookup when auto-fetch is unavailable.

Args:
  - title (string): CCR title number
  - section (string): Section number

Key Titles:
  - Title 11: Law Enforcement (POST standards)
  - Title 22: Social Services (CPS/CDSS standards)
  - Title 16: Professional & Vocational (Medical Board, Psychology Board)
  - Title 15: Crime Prevention and Corrections

Examples:
  - POST training standards: title="11", section="1005"
  - CPS investigation: title="22", section="31061"
  - Medical discipline: title="16", section="1361"`,
    inputSchema: GetRegulationInputSchema,
    annotations: {
      readOnlyHint: true,
      destructiveHint: false,
      idempotentHint: true,
      openWorldHint: true,
    },
  },
  async (params) => {
    try {
      const { title, section } = params;
      const result = await fetchRegulation(title, section);

      const titleDesc = CCR_TITLES[title] || "Unknown Title";

      const output = {
        title,
        title_name: titleDesc,
        section,
        heading: result.heading,
        text: truncateIfNeeded(result.text),
        source_url: result.url,
        citation: `${title} CCR § ${section}`,
        retrieved_at: new Date().toISOString(),
      };

      const markdown = `# ${title} CCR § ${section}

**Title ${title}:** ${titleDesc}
**Citation:** ${output.citation}
**Source:** [California Code of Regulations](${result.url})
**Retrieved:** ${output.retrieved_at}

---

## ${result.heading}

${result.text}

---

*Note: California Code of Regulations. Verify currency.*`;

      return {
        content: [{ type: "text", text: markdown }],
        structuredContent: output,
      };
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : "Unknown error occurred";
      
      // For CCR, provide helpful guidance even on error
      const titleDesc = CCR_TITLES[params.title] || "Unknown Title";
      
      return {
        isError: true,
        content: [
          {
            type: "text",
            text: `# California Code of Regulations Lookup

**Requested:** ${params.title} CCR § ${params.section}
**Title ${params.title}:** ${titleDesc}

---

## Auto-Fetch Status

${errorMessage}

---

## Alternative Sources

1. **Westlaw CalRegs (Free Public Access):**
   https://govt.westlaw.com/calregs/

2. **Office of Administrative Law:**
   https://oal.ca.gov/

3. **Specific Agency Sites:**
   - POST: https://post.ca.gov/
   - CDSS: https://cdss.ca.gov/
   - Medical Board: https://mbc.ca.gov/

---

Use \`ccr_list_titles\` to see all available titles.
Use \`ccr_list_key_regulations\` to see important sections for your case.`,
          },
        ],
      };
    }
  }
);

server.registerTool(
  "ccr_list_titles",
  {
    title: "List California Code of Regulations Titles",
    description: `List all titles in the California Code of Regulations.

Returns:
  - Complete list of CCR titles with descriptions`,
    inputSchema: ListTitlesInputSchema,
    annotations: {
      readOnlyHint: true,
      destructiveHint: false,
      idempotentHint: true,
      openWorldHint: false,
    },
  },
  async () => {
    const titles = Object.entries(CCR_TITLES).map(([num, desc]) => ({
      title_number: num,
      title_name: desc,
    }));

    const markdown = `# California Code of Regulations - Titles

| Title | Description |
|-------|-------------|
${titles.map((t) => `| ${t.title_number} | ${t.title_name} |`).join("\n")}

---

## Key Titles for Your Case

| Title | Agency | Relevance |
|-------|--------|-----------|
| **11** | POST (Law Enforcement) | Police conduct standards |
| **22** | CDSS (Social Services) | CPS investigation standards |
| **16** | DCA (Professional Licensing) | Medical Board, Psychology Board |
| **15** | CDCR (Corrections) | Prison/jail standards |

---

## Access Points

- **Westlaw CalRegs:** https://govt.westlaw.com/calregs/
- **Office of Administrative Law:** https://oal.ca.gov/
- **POST Commission:** https://post.ca.gov/
- **CDSS:** https://cdss.ca.gov/
- **Medical Board:** https://mbc.ca.gov/`;

    return {
      content: [{ type: "text", text: markdown }],
      structuredContent: { titles },
    };
  }
);

server.registerTool(
  "ccr_list_key_regulations",
  {
    title: "List Key California Regulations",
    description: `List key California Code of Regulations sections relevant to law enforcement, CPS, and medical board matters.

Args:
  - category: "post" (law enforcement), "cps" (child welfare), "medical" (physician/psych), or "all"

Returns:
  - Important regulatory sections with descriptions`,
    inputSchema: ListKeyRegulationsInputSchema,
    annotations: {
      readOnlyHint: true,
      destructiveHint: false,
      idempotentHint: true,
      openWorldHint: false,
    },
  },
  async (params) => {
    const { category } = params;

    let filteredSections = Object.entries(KEY_REGULATORY_SECTIONS);

    if (category === "post") {
      filteredSections = filteredSections.filter(([key]) => key.startsWith("post"));
    } else if (category === "cps") {
      filteredSections = filteredSections.filter(([key]) => key.startsWith("cps") || key.startsWith("foster"));
    } else if (category === "medical") {
      filteredSections = filteredSections.filter(([key]) => key.startsWith("medical") || key.startsWith("psych"));
    }

    const sections = filteredSections.map(([key, data]) => ({
      key,
      citation: `${data.title} CCR § ${data.section}`,
      title: data.title,
      section: data.section,
      description: data.description,
    }));

    const markdown = `# Key California Regulations - ${category.toUpperCase()}

## POST Standards (Title 11) - Law Enforcement

| Citation | Description |
|----------|-------------|
| 11 CCR § 1001 | POST Commission Authority |
| 11 CCR § 1002 | Peace Officer Selection Standards |
| 11 CCR § 1003 | Standards of Conduct |
| 11 CCR § 1005 | Minimum Training Standards |
| 11 CCR § 1011 | Reporting Requirements |

**Key Resource:** POST Commission website: https://post.ca.gov/

---

## CDSS Standards (Title 22) - Child Protective Services

| Citation | Description |
|----------|-------------|
| 22 CCR § 31001 | Child Abuse Reporting |
| 22 CCR § 31061 | CPS Investigation Requirements |
| 22 CCR § 31101 | Foster Care Standards |
| 22 CCR § 31501 | Emergency Response Requirements |

**Key Resource:** CDSS Manual of Policies and Procedures: https://cdss.ca.gov/inforesources/letters-regulations

---

## Medical/Psychology Board (Title 16)

| Citation | Description |
|----------|-------------|
| 16 CCR § 1361 | Grounds for Discipline |
| 16 CCR § 2234 | Unprofessional Conduct |
| 16 CCR § 1397.61 | Psychology Board Standards |

**Key Resource:** Medical Board of California: https://mbc.ca.gov/

---

Use \`ccr_get_regulation\` to attempt retrieval of specific sections.`;

    return {
      content: [{ type: "text", text: markdown }],
      structuredContent: { category, sections },
    };
  }
);

// ============================================================================
// SERVER TRANSPORT
// ============================================================================

async function runStdio(): Promise<void> {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error("California Regulations MCP Server running on stdio");
}

async function runHTTP(): Promise<void> {
  const app = express();
  app.use(express.json());

  app.get("/health", (_req: Request, res: Response) => {
    res.json({ status: "ok", server: "california-regulations-mcp-server" });
  });

  app.post("/mcp", async (req: Request, res: Response) => {
    const transport = new StreamableHTTPServerTransport({
      sessionIdGenerator: undefined,
      enableJsonResponse: true,
    });
    res.on("close", () => transport.close());
    await server.connect(transport);
    await transport.handleRequest(req, res, req.body);
  });

  const port = parseInt(process.env.PORT || "3003");
  app.listen(port, () => {
    console.error(
      `California Regulations MCP Server running on http://localhost:${port}/mcp`
    );
  });
}

const transport = process.env.TRANSPORT || "stdio";
if (transport === "http") {
  runHTTP().catch((error) => {
    console.error("Server error:", error);
    process.exit(1);
  });
} else {
  runStdio().catch((error) => {
    console.error("Server error:", error);
    process.exit(1);
  });
}
