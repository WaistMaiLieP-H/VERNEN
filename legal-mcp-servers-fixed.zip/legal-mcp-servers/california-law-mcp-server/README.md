# California Law MCP Server

An MCP (Model Context Protocol) server that retrieves **verified statutory text** directly from California's official Legislative Information database (leginfo.legislature.ca.gov).

## Why This Exists

AI models like Claude can analyze legal text with high accuracy when given the actual source material. The problem is retrieval—Claude doesn't have direct access to legal databases. This MCP server solves that by:

1. Fetching **official statutory text** from California's legislature website
2. Returning **verified, citable content** with source URLs
3. Enabling Claude to perform legal analysis on **real statutes**, not hallucinated ones

## Features

- **`california_get_section`** - Retrieve full text of any California code section
- **`california_search_code`** - Search within a code for relevant sections
- **`california_list_codes`** - List all 30 California codes with abbreviations

## Supported Codes

| Code | Name | Common Uses |
|------|------|-------------|
| FAM | Family Code | Custody, support, divorce |
| PEN | Penal Code | Crimes, sentencing, DV |
| CCP | Code of Civil Procedure | Court procedures, deadlines |
| CIV | Civil Code | Contracts, property, torts |
| GOV | Government Code | Public records, agencies |
| WIC | Welfare & Institutions | CPS, juvenile court |
| EVID | Evidence Code | Admissibility, privileges |
| PROB | Probate Code | Estates, conservatorships |
| ... | And 22 more | See `california_list_codes` |

## Installation

### Prerequisites

- Node.js 18 or higher
- npm

### Setup

```bash
# Clone or download this directory
cd california-law-mcp-server

# Install dependencies
npm install

# Build TypeScript
npm run build

# Test the server
node dist/index.js
```

## Usage

### With Claude Desktop (stdio mode)

Add to your Claude Desktop configuration (`~/.config/claude/claude_desktop_config.json` on Mac/Linux):

```json
{
  "mcpServers": {
    "california-law": {
      "command": "node",
      "args": ["/path/to/california-law-mcp-server/dist/index.js"]
    }
  }
}
```

### As HTTP Server

```bash
TRANSPORT=http PORT=3000 node dist/index.js
```

Then configure Claude to connect to `http://localhost:3000/mcp`

## Example Queries

Once connected, you can ask Claude:

- "Get Family Code section 3044 and analyze whether it applies to my situation"
- "What does Penal Code 273.5 say about domestic violence?"
- "Find sections in the Family Code about custody presumptions"
- "Get CCP 583.310 and explain the 5-year dismissal rule"

## How It Works

1. You ask Claude about a California statute
2. Claude calls this MCP server with the code and section
3. Server fetches the official text from leginfo.legislature.ca.gov
4. Claude receives verified statutory text with source URL
5. Claude analyzes the actual law—no hallucination possible

## Technical Details

- **Transport**: Supports both stdio (local) and HTTP (remote)
- **Source**: Official California Legislative Information
- **Parsing**: Uses node-html-parser for reliable text extraction
- **Error Handling**: Clear messages when sections not found

## Limitations

- Only California state codes (not federal law, not case law)
- Requires internet connection to fetch statutes
- Does not include annotations or case citations (just statutory text)
- Some complex formatting may be simplified

## Contributing

This is a foundation. Extensions could include:
- Federal US Code support (via uscode.house.gov)
- California case law (via courts.ca.gov)
- Citation parsing and cross-references
- Historical versions of statutes

## License

MIT - Use freely for legal research and self-representation.

## Disclaimer

This tool retrieves official statutory text but is not legal advice. Always verify current law and consult with an attorney for legal matters.
