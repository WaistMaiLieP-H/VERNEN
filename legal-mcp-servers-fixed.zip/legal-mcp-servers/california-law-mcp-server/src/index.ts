import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import express, { Request, Response } from "express";
import { z } from "zod";
import { parse } from "node-html-parser";

// ============================================================================
// CONSTANTS
// ============================================================================

const CALIFORNIA_CODES = [
  "BPC", // Business and Professions Code
  "CCP", // Code of Civil Procedure
  "CIV", // Civil Code
  "COM", // Commercial Code
  "CONS", // Constitution
  "CORP", // Corporations Code
  "EDC", // Education Code
  "ELEC", // Elections Code
  "EVID", // Evidence Code
  "FAC", // Food and Agricultural Code
  "FAM", // Family Code
  "FGC", // Fish and Game Code
  "FIN", // Financial Code
  "GOV", // Government Code
  "HNC", // Harbors and Navigation Code
  "HSC", // Health and Safety Code
  "INS", // Insurance Code
  "LAB", // Labor Code
  "MVC", // Military and Veterans Code
  "PCC", // Public Contract Code
  "PEN", // Penal Code
  "PROB", // Probate Code
  "PRC", // Public Resources Code
  "PUC", // Public Utilities Code
  "RTC", // Revenue and Taxation Code
  "SHC", // Streets and Highways Code
  "UIC", // Unemployment Insurance Code
  "VEH", // Vehicle Code
  "WAT", // Water Code
  "WIC", // Welfare and Institutions Code
] as const;

type CaliforniaCode = typeof CALIFORNIA_CODES[number];

const CODE_NAMES: Record<CaliforniaCode, string> = {
  BPC: "Business and Professions Code",
  CCP: "Code of Civil Procedure",
  CIV: "Civil Code",
  COM: "Commercial Code",
  CONS: "California Constitution",
  CORP: "Corporations Code",
  EDC: "Education Code",
  ELEC: "Elections Code",
  EVID: "Evidence Code",
  FAC: "Food and Agricultural Code",
  FAM: "Family Code",
  FGC: "Fish and Game Code",
  FIN: "Financial Code",
  GOV: "Government Code",
  HNC: "Harbors and Navigation Code",
  HSC: "Health and Safety Code",
  INS: "Insurance Code",
  LAB: "Labor Code",
  MVC: "Military and Veterans Code",
  PCC: "Public Contract Code",
  PEN: "Penal Code",
  PROB: "Probate Code",
  PRC: "Public Resources Code",
  PUC: "Public Utilities Code",
  RTC: "Revenue and Taxation Code",
  SHC: "Streets and Highways Code",
  UIC: "Unemployment Insurance Code",
  VEH: "Vehicle Code",
  WAT: "Water Code",
  WIC: "Welfare and Institutions Code",
};

const LEGINFO_BASE_URL = "https://leginfo.legislature.ca.gov";
const CHARACTER_LIMIT = 50000;

// ============================================================================
// SERVER INITIALIZATION
// ============================================================================

const server = new McpServer({
  name: "california-law-mcp-server",
  version: "1.0.0",
});

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

async function fetchWithTimeout(
  url: string,
  timeoutMs: number = 30000
): Promise<string> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: {
        "User-Agent":
          "California-Law-MCP-Server/1.0 (Legal Research Tool)",
        Accept: "text/html,application/xhtml+xml",
      },
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    return await response.text();
  } finally {
    clearTimeout(timeoutId);
  }
}

function cleanText(text: string): string {
  return text
    .replace(/\s+/g, " ")
    .replace(/\n\s*\n/g, "\n\n")
    .trim();
}

function truncateIfNeeded(text: string, limit: number = CHARACTER_LIMIT): string {
  if (text.length <= limit) return text;
  return (
    text.substring(0, limit) +
    `\n\n[TRUNCATED - Response exceeded ${limit} characters. Use section parameter for specific sections.]`
  );
}

// ============================================================================
// CALIFORNIA CODE FETCHER
// ============================================================================

async function fetchCaliforniaSection(
  code: CaliforniaCode,
  section: string
): Promise<{ text: string; url: string; title: string }> {
  // Build URL for California Legislative Information
  // Format: https://leginfo.legislature.ca.gov/faces/codes_displaySection.xhtml?sectionNum=3044.&lawCode=FAM
  const sectionForUrl = section.includes(".") ? section : `${section}.`;
  const url = `${LEGINFO_BASE_URL}/faces/codes_displaySection.xhtml?sectionNum=${encodeURIComponent(
    sectionForUrl
  )}&lawCode=${code}`;

  const html = await fetchWithTimeout(url);
  const root = parse(html);

  // Extract section content from the page
  // California leginfo uses various div IDs and classes
  const contentDiv = root.querySelector("#codeLawSectionNo498702") ||
    root.querySelector("[id^='codeLawSection']") ||
    root.querySelector("#codeDisplayText") ||
    root.querySelector(".code-section-body") ||
    root.querySelector("#lawSectionContent") ||
    root.querySelector(".law-section-body") ||
    root.querySelector("#manylawsections") ||
    root.querySelector(".content_main") ||
    root.querySelector("#lawCode");

  if (!contentDiv) {
    // Try to get body content as fallback
    const bodyContent = root.querySelector("body");
    if (bodyContent) {
      // Look for any div containing section text patterns
      const allDivs = root.querySelectorAll("div");
      for (const div of allDivs) {
        const text = div.text;
        if (text.includes(`${section}.`) && text.length > 200) {
          return {
            text: cleanText(text),
            url,
            title: `${CODE_NAMES[code]} § ${section}`,
          };
        }
      }
    }
    
    // Try to find any error message
    const errorDiv = root.querySelector(".error-message") ||
      root.querySelector("#messages") ||
      root.querySelector(".ui-messages-error");
    if (errorDiv) {
      throw new Error(`Section not found: ${errorDiv.text.trim()}`);
    }
    throw new Error(
      `Could not parse section content. The section may not exist or the page structure may have changed. URL: ${url}`
    );
  }

  // Get the section title/heading
  const titleElement = root.querySelector("#sectionHeading") ||
    root.querySelector(".law-section-heading") ||
    root.querySelector("h1") ||
    root.querySelector(".codeTitle") ||
    root.querySelector("[id^='lawSectionHeading']");
  const title = titleElement
    ? cleanText(titleElement.text)
    : `${CODE_NAMES[code]} § ${section}`;

  // Clean up the text content
  let text = contentDiv.text;
  text = cleanText(text);

  return {
    text,
    url,
    title,
  };
}

async function searchCaliforniaCode(
  code: CaliforniaCode,
  query: string
): Promise<Array<{ section: string; title: string; url: string }>> {
  // Use the search functionality
  const searchUrl = `${LEGINFO_BASE_URL}/faces/codes_displayexpandedbranch.xhtml?lawCode=${code}&tocId=&tocPath=`;

  const html = await fetchWithTimeout(searchUrl);
  const root = parse(html);

  // Find sections that match the query
  const results: Array<{ section: string; title: string; url: string }> = [];
  const links = root.querySelectorAll("a[href*='codes_displaySection']");

  for (const link of links) {
    const text = link.text.toLowerCase();
    const href = link.getAttribute("href") || "";

    if (text.includes(query.toLowerCase())) {
      // Extract section number from URL or text
      const sectionMatch = href.match(/sectionNum=([^&]+)/);
      const section = sectionMatch
        ? decodeURIComponent(sectionMatch[1]).replace(".", "")
        : "";

      if (section) {
        results.push({
          section,
          title: cleanText(link.text),
          url: `${LEGINFO_BASE_URL}${href}`,
        });
      }
    }

    if (results.length >= 20) break; // Limit results
  }

  return results;
}

// ============================================================================
// TOOL SCHEMAS
// ============================================================================

const GetSectionInputSchema = z
  .object({
    code: z
      .enum(CALIFORNIA_CODES)
      .describe(
        `California code abbreviation. Common codes: FAM (Family), PEN (Penal), CCP (Civil Procedure), CIV (Civil), GOV (Government), WIC (Welfare & Institutions), EVID (Evidence), PROB (Probate)`
      ),
    section: z
      .string()
      .min(1)
      .max(50)
      .describe(
        `Section number (e.g., "3044", "3044.5", "240"). Include subsection if needed.`
      ),
  })
  .strict();

const SearchCodeInputSchema = z
  .object({
    code: z
      .enum(CALIFORNIA_CODES)
      .describe(`California code to search within`),
    query: z
      .string()
      .min(2)
      .max(100)
      .describe(`Search terms to find relevant sections`),
  })
  .strict();

const ListCodesInputSchema = z.object({}).strict();

// ============================================================================
// TOOL REGISTRATION
// ============================================================================

server.registerTool(
  "california_get_section",
  {
    title: "Get California Code Section",
    description: `Retrieve the full text of a specific California statutory section from the official California Legislative Information database.

This tool fetches VERIFIED statutory text directly from leginfo.legislature.ca.gov - the official source. Use this when you need the exact language of a California law.

Args:
  - code (string): California code abbreviation. Common codes:
    * FAM - Family Code (custody, support, divorce)
    * PEN - Penal Code (crimes, sentencing)
    * CCP - Code of Civil Procedure (court procedures, deadlines)
    * CIV - Civil Code (contracts, property, torts)
    * GOV - Government Code (public agencies, records)
    * WIC - Welfare and Institutions Code (CPS, juvenile)
    * EVID - Evidence Code (admissibility, privileges)
    * PROB - Probate Code (estates, conservatorships)
  - section (string): Section number (e.g., "3044", "3044.5", "240")

Returns:
  - Full statutory text from official source
  - Direct URL to the official page
  - Section title/heading

Examples:
  - Family Code § 3044 (DV custody presumption): code="FAM", section="3044"
  - Penal Code § 273.5 (domestic violence): code="PEN", section="273.5"
  - CCP § 583.310 (5-year dismissal rule): code="CCP", section="583.310"

Error Handling:
  - Returns clear error if section not found
  - Returns error if official site is unavailable`,
    inputSchema: GetSectionInputSchema,
    annotations: {
      readOnlyHint: true,
      destructiveHint: false,
      idempotentHint: true,
      openWorldHint: true,
    },
  },
  async (params) => {
    try {
      const { code, section } = params;
      const result = await fetchCaliforniaSection(code, section);

      const output = {
        code: code,
        code_name: CODE_NAMES[code],
        section: section,
        title: result.title,
        text: truncateIfNeeded(result.text),
        source_url: result.url,
        retrieved_at: new Date().toISOString(),
        disclaimer:
          "This is the official statutory text from leginfo.legislature.ca.gov. Always verify currency and check for recent amendments.",
      };

      const markdown = `# ${CODE_NAMES[code]} § ${section}

**Source:** [Official California Legislative Information](${result.url})
**Retrieved:** ${output.retrieved_at}

---

## ${result.title}

${result.text}

---

*Note: This is official statutory text. Verify currency for any court filing.*`;

      return {
        content: [{ type: "text", text: markdown }],
        structuredContent: output,
      };
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : "Unknown error occurred";
      return {
        isError: true,
        content: [
          {
            type: "text",
            text: `Error retrieving ${params.code} § ${params.section}: ${errorMessage}\n\nTry:\n1. Verify the section number exists\n2. Check the code abbreviation is correct\n3. Use california_list_codes to see available codes`,
          },
        ],
      };
    }
  }
);

server.registerTool(
  "california_search_code",
  {
    title: "Search California Code",
    description: `Search within a California code for sections matching keywords.

Use this when you don't know the exact section number but need to find relevant statutes.

Args:
  - code (string): California code to search within
  - query (string): Search terms (e.g., "custody presumption", "domestic violence")

Returns:
  - List of matching sections with titles and URLs
  - Limited to 20 most relevant results

Examples:
  - Find custody sections: code="FAM", query="custody presumption"
  - Find DV statutes: code="PEN", query="domestic violence"`,
    inputSchema: SearchCodeInputSchema,
    annotations: {
      readOnlyHint: true,
      destructiveHint: false,
      idempotentHint: true,
      openWorldHint: true,
    },
  },
  async (params) => {
    try {
      const { code, query } = params;
      const results = await searchCaliforniaCode(code, query);

      if (results.length === 0) {
        return {
          content: [
            {
              type: "text",
              text: `No sections found in ${CODE_NAMES[code]} matching "${query}".\n\nTry:\n1. Use broader search terms\n2. Check spelling\n3. Try a different code (use california_list_codes to see options)`,
            },
          ],
        };
      }

      const output = {
        code: code,
        code_name: CODE_NAMES[code],
        query: query,
        result_count: results.length,
        results: results,
      };

      const markdown = `# Search Results: ${CODE_NAMES[code]}

**Query:** "${query}"
**Results:** ${results.length} sections found

---

${results
  .map(
    (r, i) =>
      `${i + 1}. **§ ${r.section}** - ${r.title}\n   [View Section](${r.url})`
  )
  .join("\n\n")}

---

*Use california_get_section to retrieve the full text of any section.*`;

      return {
        content: [{ type: "text", text: markdown }],
        structuredContent: output,
      };
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : "Unknown error occurred";
      return {
        isError: true,
        content: [
          {
            type: "text",
            text: `Error searching ${params.code}: ${errorMessage}`,
          },
        ],
      };
    }
  }
);

server.registerTool(
  "california_list_codes",
  {
    title: "List California Codes",
    description: `List all available California codes and their abbreviations.

Use this to find the correct code abbreviation for a topic area.

Returns:
  - Complete list of California code abbreviations
  - Full names for each code
  - Common use cases`,
    inputSchema: ListCodesInputSchema,
    annotations: {
      readOnlyHint: true,
      destructiveHint: false,
      idempotentHint: true,
      openWorldHint: false,
    },
  },
  async () => {
    const codeList = CALIFORNIA_CODES.map((code) => ({
      abbreviation: code,
      name: CODE_NAMES[code],
    }));

    const markdown = `# California Codes

| Abbreviation | Full Name |
|--------------|-----------|
${codeList.map((c) => `| ${c.abbreviation} | ${c.name} |`).join("\n")}

---

## Common Codes by Topic

**Family Law:** FAM (Family Code), CCP (Civil Procedure), EVID (Evidence)
**Criminal:** PEN (Penal Code), EVID (Evidence)
**Child Welfare:** WIC (Welfare & Institutions), FAM (Family Code)
**Civil Litigation:** CCP (Civil Procedure), CIV (Civil Code), EVID (Evidence)
**Government/Records:** GOV (Government Code)
**Estates/Guardianship:** PROB (Probate Code)`;

    return {
      content: [{ type: "text", text: markdown }],
      structuredContent: { codes: codeList },
    };
  }
);

// ============================================================================
// SERVER TRANSPORT
// ============================================================================

async function runStdio(): Promise<void> {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error("California Law MCP Server running on stdio");
}

async function runHTTP(): Promise<void> {
  const app = express();
  app.use(express.json());

  // Health check endpoint
  app.get("/health", (_req: Request, res: Response) => {
    res.json({ status: "ok", server: "california-law-mcp-server" });
  });

  // MCP endpoint
  app.post("/mcp", async (req: Request, res: Response) => {
    const transport = new StreamableHTTPServerTransport({
      sessionIdGenerator: undefined,
      enableJsonResponse: true,
    });
    res.on("close", () => transport.close());
    await server.connect(transport);
    await transport.handleRequest(req, res, req.body);
  });

  const port = parseInt(process.env.PORT || "3000");
  app.listen(port, () => {
    console.error(`California Law MCP Server running on http://localhost:${port}/mcp`);
  });
}

// Choose transport based on environment
const transport = process.env.TRANSPORT || "stdio";
if (transport === "http") {
  runHTTP().catch((error) => {
    console.error("Server error:", error);
    process.exit(1);
  });
} else {
  runStdio().catch((error) => {
    console.error("Server error:", error);
    process.exit(1);
  });
}
