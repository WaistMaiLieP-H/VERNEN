import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import express, { Request, Response } from "express";
import { z } from "zod";
import { parse } from "node-html-parser";

// ============================================================================
// CONSTANTS
// ============================================================================

const CRC_TITLES = {
  "1": "Rules Applicable to All Courts",
  "2": "Trial Court Rules",
  "3": "Civil Rules",
  "4": "Criminal Rules",
  "5": "Family and Juvenile Rules",
  "6": "Reserved",
  "7": "Probate Rules",
  "8": "Appellate Rules",
  "9": "Rules on Law Practice, Attorneys, and Judges",
  "10": "Judicial Administration Rules",
} as const;

const TITLE_NAMES: Record<string, string> = {
  "1": "one",
  "2": "two",
  "3": "three",
  "4": "four",
  "5": "five",
  "6": "six",
  "7": "seven",
  "8": "eight",
  "9": "nine",
  "10": "ten",
};

// Key rules for family law / custody evaluations
const KEY_FAMILY_RULES: Record<string, string> = {
  "5.210": "Court-connected child custody mediation",
  "5.215": "Domestic violence protocol for mediators",
  "5.220": "Court-ordered child custody evaluations",
  "5.225": "Child custody recommending counselors",
  "5.230": "Appointment requirements for child custody evaluators",
  "5.235": "Qualifications, rights, and responsibilities of counsel",
  "5.240": "Court-ordered mediation",
  "5.241": "Appointment of child custody evaluator",
  "5.242": "Parenting plan counseling",
  "5.250": "Children's participation and testimony in family court",
  "5.260": "Children's holiday schedule",
  "5.270": "Ex parte communication in child custody proceedings",
};

const COURTS_CA_BASE = "https://www.courts.ca.gov";
const CHARACTER_LIMIT = 50000;

// ============================================================================
// SERVER INITIALIZATION
// ============================================================================

const server = new McpServer({
  name: "california-rules-of-court-mcp-server",
  version: "1.0.0",
});

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

async function fetchWithTimeout(
  url: string,
  timeoutMs: number = 30000
): Promise<string> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: {
        "User-Agent": "California-Rules-MCP-Server/1.0 (Legal Research Tool)",
        Accept: "text/html,application/xhtml+xml",
      },
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    return await response.text();
  } finally {
    clearTimeout(timeoutId);
  }
}

function cleanText(text: string): string {
  return text
    .replace(/\s+/g, " ")
    .replace(/\n\s*\n/g, "\n\n")
    .trim();
}

function truncateIfNeeded(text: string, limit: number = CHARACTER_LIMIT): string {
  if (text.length <= limit) return text;
  return (
    text.substring(0, limit) +
    `\n\n[TRUNCATED - Response exceeded ${limit} characters.]`
  );
}

// ============================================================================
// CALIFORNIA RULES OF COURT FETCHER
// ============================================================================

async function fetchRule(
  ruleNumber: string
): Promise<{ text: string; url: string; title: string }> {
  // Parse rule number to determine title
  // Rule 5.220 -> Title 5, linkid = rule5_220
  const match = ruleNumber.match(/^(\d+)\.(\d+)$/);
  if (!match) {
    throw new Error(
      `Invalid rule format: "${ruleNumber}". Use format like "5.220" or "3.1540"`
    );
  }

  const titleNum = match[1];
  const ruleNum = match[2];
  const titleName = TITLE_NAMES[titleNum];

  if (!titleName) {
    throw new Error(`Unknown title number: ${titleNum}. Valid titles are 1-10.`);
  }

  // Build URL
  // Format: https://www.courts.ca.gov/cms/rules/index.cfm?title=five&linkid=rule5_220
  const linkId = `rule${titleNum}_${ruleNum}`;
  const url = `${COURTS_CA_BASE}/cms/rules/index.cfm?title=${titleName}&linkid=${linkId}`;

  const html = await fetchWithTimeout(url);
  const root = parse(html);

  // Extract rule content
  const contentDiv =
    root.querySelector(".rule-content") ||
    root.querySelector(".content-main") ||
    root.querySelector("#content") ||
    root.querySelector("article") ||
    root.querySelector(".rules-content");

  if (!contentDiv) {
    // Check for error or redirect
    const bodyText = root.querySelector("body")?.text || "";
    if (
      bodyText.includes("not found") ||
      bodyText.includes("does not exist")
    ) {
      throw new Error(`Rule ${ruleNumber} not found in California Rules of Court.`);
    }
    throw new Error(
      `Could not parse rule content. The page structure may have changed.`
    );
  }

  // Get title
  const titleElement =
    root.querySelector("h1") ||
    root.querySelector(".rule-title") ||
    root.querySelector("h2");
  const title = titleElement
    ? cleanText(titleElement.text)
    : `California Rules of Court, Rule ${ruleNumber}`;

  let text = contentDiv.text;
  text = cleanText(text);

  return { text, url, title };
}

async function searchRules(
  query: string,
  titleFilter?: string
): Promise<Array<{ rule: string; title: string; url: string }>> {
  // For now, return key rules that match the query from our known list
  // A full implementation would scrape the search results
  const results: Array<{ rule: string; title: string; url: string }> = [];
  const queryLower = query.toLowerCase();

  for (const [rule, description] of Object.entries(KEY_FAMILY_RULES)) {
    if (
      description.toLowerCase().includes(queryLower) ||
      rule.includes(query)
    ) {
      if (!titleFilter || rule.startsWith(titleFilter)) {
        const titleNum = rule.split(".")[0];
        const ruleNum = rule.split(".")[1];
        const titleName = TITLE_NAMES[titleNum];
        results.push({
          rule,
          title: description,
          url: `${COURTS_CA_BASE}/cms/rules/index.cfm?title=${titleName}&linkid=rule${titleNum}_${ruleNum}`,
        });
      }
    }
  }

  return results;
}

// ============================================================================
// TOOL SCHEMAS
// ============================================================================

const GetRuleInputSchema = z
  .object({
    rule: z
      .string()
      .regex(/^\d+\.\d+$/, "Rule must be in format 'X.XXX' (e.g., '5.220')")
      .describe(
        `California Rules of Court rule number (e.g., "5.220" for custody evaluations, "5.225" for recommending counselors)`
      ),
  })
  .strict();

const SearchRulesInputSchema = z
  .object({
    query: z
      .string()
      .min(2)
      .max(100)
      .describe(`Search terms (e.g., "custody evaluation", "mediator", "domestic violence")`),
    title: z
      .string()
      .regex(/^\d+$/)
      .optional()
      .describe(`Filter by title number (e.g., "5" for Family and Juvenile Rules)`),
  })
  .strict();

const ListTitlesInputSchema = z.object({}).strict();

const ListKeyRulesInputSchema = z
  .object({
    topic: z
      .enum(["family", "custody", "mediation", "all"])
      .default("all")
      .describe(`Topic area to list key rules for`),
  })
  .strict();

// ============================================================================
// TOOL REGISTRATION
// ============================================================================

server.registerTool(
  "crc_get_rule",
  {
    title: "Get California Rule of Court",
    description: `Retrieve the full text of a California Rule of Court from the official courts.ca.gov website.

This tool fetches VERIFIED rule text directly from the California Courts website.

Args:
  - rule (string): Rule number in format "X.XXX" (e.g., "5.220")

Key Family Law Rules:
  - 5.210: Court-connected child custody mediation
  - 5.215: Domestic violence protocol for mediators
  - 5.220: Court-ordered child custody evaluations
  - 5.225: Child custody recommending counselors
  - 5.230: Appointment requirements for evaluators
  - 5.250: Children's participation and testimony

Returns:
  - Full rule text from official source
  - Direct URL to the official page
  - Rule title

Examples:
  - CRC 5.220 (custody evaluations): rule="5.220"
  - CRC 5.225 (recommending counselors): rule="5.225"
  - CRC 5.215 (DV protocol): rule="5.215"`,
    inputSchema: GetRuleInputSchema,
    annotations: {
      readOnlyHint: true,
      destructiveHint: false,
      idempotentHint: true,
      openWorldHint: true,
    },
  },
  async (params) => {
    try {
      const { rule } = params;
      const result = await fetchRule(rule);

      const titleNum = rule.split(".")[0];
      const titleDesc = CRC_TITLES[titleNum as keyof typeof CRC_TITLES] || "Unknown Title";

      const output = {
        rule: rule,
        title: result.title,
        crc_title: `Title ${titleNum}: ${titleDesc}`,
        text: truncateIfNeeded(result.text),
        source_url: result.url,
        retrieved_at: new Date().toISOString(),
        disclaimer:
          "This is the official rule text from courts.ca.gov. Always verify currency.",
      };

      const markdown = `# California Rules of Court, Rule ${rule}

**Title:** ${titleNum} - ${titleDesc}
**Source:** [Official California Courts](${result.url})
**Retrieved:** ${output.retrieved_at}

---

## ${result.title}

${result.text}

---

*Note: This is official rule text. Verify currency for any court filing.*`;

      return {
        content: [{ type: "text", text: markdown }],
        structuredContent: output,
      };
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : "Unknown error occurred";
      return {
        isError: true,
        content: [
          {
            type: "text",
            text: `Error retrieving CRC Rule ${params.rule}: ${errorMessage}\n\nTry:\n1. Verify the rule number format (e.g., "5.220")\n2. Use crc_list_key_rules to see common rules\n3. Use crc_list_titles to see available titles`,
          },
        ],
      };
    }
  }
);

server.registerTool(
  "crc_search_rules",
  {
    title: "Search California Rules of Court",
    description: `Search for California Rules of Court by keyword.

Args:
  - query (string): Search terms
  - title (string, optional): Filter by title number (e.g., "5" for Family)

Returns:
  - List of matching rules with descriptions and URLs`,
    inputSchema: SearchRulesInputSchema,
    annotations: {
      readOnlyHint: true,
      destructiveHint: false,
      idempotentHint: true,
      openWorldHint: true,
    },
  },
  async (params) => {
    try {
      const { query, title } = params;
      const results = await searchRules(query, title);

      if (results.length === 0) {
        return {
          content: [
            {
              type: "text",
              text: `No rules found matching "${query}".\n\nTry:\n1. Use broader search terms\n2. Use crc_list_key_rules to see known rules\n3. Check crc_list_titles for the correct title number`,
            },
          ],
        };
      }

      const output = {
        query,
        title_filter: title || null,
        result_count: results.length,
        results,
      };

      const markdown = `# Search Results: California Rules of Court

**Query:** "${query}"
${title ? `**Title Filter:** ${title}` : ""}
**Results:** ${results.length} rules found

---

${results
  .map(
    (r, i) =>
      `${i + 1}. **Rule ${r.rule}** - ${r.title}\n   [View Rule](${r.url})`
  )
  .join("\n\n")}

---

*Use crc_get_rule to retrieve the full text of any rule.*`;

      return {
        content: [{ type: "text", text: markdown }],
        structuredContent: output,
      };
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : "Unknown error occurred";
      return {
        isError: true,
        content: [
          {
            type: "text",
            text: `Error searching rules: ${errorMessage}`,
          },
        ],
      };
    }
  }
);

server.registerTool(
  "crc_list_titles",
  {
    title: "List California Rules of Court Titles",
    description: `List all titles in the California Rules of Court.

Returns:
  - Complete list of CRC titles with descriptions`,
    inputSchema: ListTitlesInputSchema,
    annotations: {
      readOnlyHint: true,
      destructiveHint: false,
      idempotentHint: true,
      openWorldHint: false,
    },
  },
  async () => {
    const titles = Object.entries(CRC_TITLES).map(([num, desc]) => ({
      title_number: num,
      title_name: desc,
    }));

    const markdown = `# California Rules of Court - Titles

| Title | Description |
|-------|-------------|
${titles.map((t) => `| ${t.title_number} | ${t.title_name} |`).join("\n")}

---

## Key Titles for Family/Custody Matters

- **Title 5**: Family and Juvenile Rules (custody, support, mediation)
- **Title 3**: Civil Rules (general procedure)
- **Title 7**: Probate Rules (conservatorships, guardianships)

Use \`crc_get_rule\` with format "TITLE.RULE" (e.g., "5.220")`;

    return {
      content: [{ type: "text", text: markdown }],
      structuredContent: { titles },
    };
  }
);

server.registerTool(
  "crc_list_key_rules",
  {
    title: "List Key California Rules of Court",
    description: `List key California Rules of Court for family law and custody matters.

Args:
  - topic: "family", "custody", "mediation", or "all"

Returns:
  - List of important rules with descriptions`,
    inputSchema: ListKeyRulesInputSchema,
    annotations: {
      readOnlyHint: true,
      destructiveHint: false,
      idempotentHint: true,
      openWorldHint: false,
    },
  },
  async (params) => {
    const { topic } = params;

    let rules = Object.entries(KEY_FAMILY_RULES);

    if (topic === "custody") {
      rules = rules.filter(([_, desc]) =>
        desc.toLowerCase().includes("custody") ||
        desc.toLowerCase().includes("evaluation")
      );
    } else if (topic === "mediation") {
      rules = rules.filter(([_, desc]) =>
        desc.toLowerCase().includes("mediation") ||
        desc.toLowerCase().includes("mediator") ||
        desc.toLowerCase().includes("counselor")
      );
    }

    const ruleList = rules.map(([rule, desc]) => {
      const titleNum = rule.split(".")[0];
      const ruleNum = rule.split(".")[1];
      const titleName = TITLE_NAMES[titleNum];
      return {
        rule,
        description: desc,
        url: `${COURTS_CA_BASE}/cms/rules/index.cfm?title=${titleName}&linkid=rule${titleNum}_${ruleNum}`,
      };
    });

    const markdown = `# Key California Rules of Court - ${topic.charAt(0).toUpperCase() + topic.slice(1)}

| Rule | Description |
|------|-------------|
${ruleList.map((r) => `| ${r.rule} | ${r.description} |`).join("\n")}

---

## Most Critical for Custody Evaluations

- **Rule 5.220**: Standards for court-ordered custody evaluations
- **Rule 5.225**: Requirements for recommending counselors (FCS)
- **Rule 5.215**: Domestic violence screening protocols
- **Rule 5.230**: Appointment requirements for evaluators

Use \`crc_get_rule\` to retrieve full text.`;

    return {
      content: [{ type: "text", text: markdown }],
      structuredContent: { topic, rules: ruleList },
    };
  }
);

// ============================================================================
// SERVER TRANSPORT
// ============================================================================

async function runStdio(): Promise<void> {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error("California Rules of Court MCP Server running on stdio");
}

async function runHTTP(): Promise<void> {
  const app = express();
  app.use(express.json());

  app.get("/health", (_req: Request, res: Response) => {
    res.json({ status: "ok", server: "california-rules-of-court-mcp-server" });
  });

  app.post("/mcp", async (req: Request, res: Response) => {
    const transport = new StreamableHTTPServerTransport({
      sessionIdGenerator: undefined,
      enableJsonResponse: true,
    });
    res.on("close", () => transport.close());
    await server.connect(transport);
    await transport.handleRequest(req, res, req.body);
  });

  const port = parseInt(process.env.PORT || "3001");
  app.listen(port, () => {
    console.error(
      `California Rules of Court MCP Server running on http://localhost:${port}/mcp`
    );
  });
}

const transport = process.env.TRANSPORT || "stdio";
if (transport === "http") {
  runHTTP().catch((error) => {
    console.error("Server error:", error);
    process.exit(1);
  });
} else {
  runStdio().catch((error) => {
    console.error("Server error:", error);
    process.exit(1);
  });
}
